from google.oauth2 import service_account
from googleapiclient.discovery import build
import datetime
import smtplib
from email.mime.text import MIMEText

# Ruta a tu archivo de credenciales de cuenta de servicio
SERVICE_ACCOUNT_FILE = 'gen-lang-client-0838152118-ebd70a8193a2.json'

# Definir los alcances necesarios para manipular eventos de calendario
SCOPES = ['https://www.googleapis.com/auth/calendar']

# Cargar las credenciales
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE,
    scopes=SCOPES
)

# Crear el cliente para el API de Calendar
service = build('calendar', 'v3', credentials=credentials)

# El calendario es el de la cuenta de servicio
calendar_id = 'primary'

# Correo de la psicóloga (opcional, si quieres mostrarlo como referencia)
correo_psicologa = 'karla52zb@gmail.com'

def crear_cita(nombre, fecha, hora, tema, correo_usuario):
    # Validar y formatear la fecha y hora
    hora_formateada = datetime.datetime.strptime(hora, "%H:%M").strftime("%H:%M")
    hora_inicio = f"{fecha}T{hora_formateada}:00"
    dt_inicio = datetime.datetime.fromisoformat(hora_inicio)
    dt_fin = dt_inicio + datetime.timedelta(minutes=30)

    evento = {
        'summary': f'Cita con {nombre}',
        'description': f'Tema: {tema}',
        'start': {
            'dateTime': dt_inicio.isoformat(),
            'timeZone': 'America/Mexico_City',
        },
        'end': {
            'dateTime': dt_fin.isoformat(),
            'timeZone': 'America/Mexico_City',
        },
    }

    event = service.events().insert(calendarId=calendar_id, body=evento).execute()

    # Enviar correo al usuario
    enviar_correo_confirmacion(correo_usuario, nombre, fecha, hora, tema)

    return event.get('htmlLink')


# ---------------- Enviar correo al usuario ----------------
def enviar_correo_confirmacion(destinatario, nombre, fecha, hora, tema):
    remitente = "tucorreo@gmail.com"
    contraseña = "tu-app-password"  # Usa App Password si tienes 2FA

    asunto = "Confirmación de cita"
    cuerpo = f"""Hola {nombre},

Tu cita fue agendada con éxito:

📅 Fecha: {fecha}
🕒 Hora: {hora}
🧠 Tema: {tema}

Gracias por agendar tu cita. Nos vemos pronto.

Saludos,
ApoyoEmocional Bot
"""

    msg = MIMEText(cuerpo)
    msg['Subject'] = asunto
    msg['From'] = remitente
    msg['To'] = destinatario

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(remitente, contraseña)
            smtp.send_message(msg)
    except Exception as e:
        print(f"❌ Error al enviar correo: {e}")
