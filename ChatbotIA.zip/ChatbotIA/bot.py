import logging
from telegram import Update
from pln_respuestas import generar_respuesta
#from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, filters, ContextTypes, handle_message
from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, filters, ContextTypes

from google_calendar_bot import crear_cita  # tu función para agendar


# --- 1. Configuración Inicial ---
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Token de tu bot
BOT_TOKEN = "7550990980:AAFB5oGvg4GC_zstquoXOgIUbqtop1rRKqI"

# --- 2. Comandos ---
async def ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Aquí tienes algunas cosas que puedo hacer:\n"
        "/respiracion - Te guío en un ejercicio de respiración.\n"
        "/tipsestudio - Consejos para manejar el estrés académico.\n"
        "/psicologia - Información para contactar al departamento de psicología.\n"
        "También puedes escribirme cómo te sientes y veré cómo puedo ayudarte."
    )

async def respiracion(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "🌬️ **Ejercicio de Respiración para Calmar la Ansiedad** 🧘‍♂️\n\n"
        "Vamos a hacer una técnica llamada **4-7-8**. Te ayudará a calmar tu mente y cuerpo. Empecemos:\n\n"
        "🔹 *Paso 1:* Inhala lentamente por la nariz mientras cuentas hasta **4**...\n"
        "🔹 *Paso 2:* Mantén el aire en tus pulmones mientras cuentas hasta **7**...\n"
        "🔹 *Paso 3:* Exhala suavemente por la boca mientras cuentas hasta **8**...\n\n"
        "Repite esto entre 3 y 5 veces. Cierra los ojos si lo deseas, y enfócate solo en tu respiración. 🍃\n\n"
        "🗨️ *¿No te funcionó?* Puedes seguir charlando conmigo para ver si puedo ayudarte.",
        parse_mode="Markdown"
    )

async def tips_estudio(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📘 **Tips para Manejar el Estrés Académico**\n\n"
        "Aquí tienes algunas recomendaciones que pueden ayudarte a estudiar con más calma y eficacia:\n\n"
        "🔹 *Organiza tu tiempo* con un horario realista y flexible.\n"
        "🔹 *Toma descansos* regulares (5 a 10 minutos cada hora).\n"
        "🔹 *Duerme bien* y mantén una alimentación balanceada.\n"
        "🔹 *Habla con tus profesores o compañeros* si necesitas apoyo.\n\n"
        "💡 *¿Te sigues sintiendo abrumado?* Puedes seguir conversando conmigo. 🤝",
        parse_mode="Markdown"
    )

async def psicologia(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "🧠 **Apoyo Profesional - Psicología Escolar**\n\n"
        "Si estás pasando por un momento difícil o necesitas hablar con alguien, el Departamento de Psicología Escolar está disponible para ti. Aquí tienes sus datos de contacto:\n\n"
        "📞 **Teléfono:** +52 833 123 4567\n"
        "📧 **Correo Electrónico:** psicologia@tuinstituto.edu.mx\n"
        "🕐 **Horario de atención:** Lunes a Viernes, 8:00 a.m. - 3:00 p.m.\n"
        "📍 **Ubicación:** Edificio C, planta alta (ver mapa: [Ubicación en Google Maps](https://maps.google.com))\n"
        "🌐 **Sitio web:** [Visita la página oficial](https://www.tuinstituto.edu.mx/psicologia)\n\n"
        "Recuerda: pedir ayuda también es una forma de cuidar de ti. 🤝",
        parse_mode="Markdown"
    )

# --- 3. Cita paso a paso ---
PEDIR_FECHA, PEDIR_HORA, PEDIR_TEMA, PEDIR_NOMBRE, PEDIR_CORREO = range(5)

async def iniciar_cita(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("¿Qué día quieres agendar la cita? (Formato: AAAA-MM-DD)")
    return PEDIR_FECHA

from datetime import datetime

async def recibir_fecha(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto_fecha = update.message.text.strip()
    try:
        # Validar formato y que no sea una fecha pasada
        fecha_obj = datetime.strptime(texto_fecha, "%Y-%m-%d").date()
        hoy = datetime.now().date()
        if fecha_obj < hoy:
            await update.message.reply_text("❌ Esa fecha ya pasó. Ingresa una fecha futura con el formato AAAA-MM-DD.")
            return PEDIR_FECHA
        context.user_data['fecha'] = texto_fecha
        await update.message.reply_text("¿A qué hora? (Formato: HH:MM en 24h)")
        return PEDIR_HORA
    except ValueError:
        await update.message.reply_text("⚠️ El formato de fecha no es válido. Usa el formato AAAA-MM-DD.")
        return PEDIR_FECHA


async def recibir_hora(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto_hora = update.message.text.strip()
    try:
        hora_obj = datetime.strptime(texto_hora, "%H:%M").time()
        # Opcional: restringir horario (ej. entre 08:00 y 18:00)
        if hora_obj < datetime.strptime("08:00", "%H:%M").time() or hora_obj > datetime.strptime("18:00", "%H:%M").time():
            await update.message.reply_text("⏰ Por favor ingresa una hora entre 08:00 y 18:00.")
            return PEDIR_HORA
        context.user_data['hora'] = texto_hora
        await update.message.reply_text("¿Cuál es el tema de la cita?")
        return PEDIR_TEMA
    except ValueError:
        await update.message.reply_text("⚠️ El formato de hora no es válido. Usa el formato HH:MM en 24 horas.")
        return PEDIR_HORA


async def recibir_tema(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['tema'] = update.message.text
    await update.message.reply_text("¿Cuál es tu nombre?")
    return PEDIR_NOMBRE

async def recibir_nombre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['nombre'] = update.message.text
    await update.message.reply_text("¿Cuál es tu correo electrónico?")
    return PEDIR_CORREO

async def recibir_correo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['correo'] = update.message.text

    nombre = context.user_data['nombre']
    fecha = context.user_data['fecha']
    hora = context.user_data['hora']
    tema = context.user_data['tema']
    correo = context.user_data['correo']

    try:
        link = crear_cita(nombre, fecha, hora, tema, correo)
        await update.message.reply_text(f"✅ Cita agendada correctamente.\n📅 Aquí tienes el enlace: {link}")
    except Exception as e:
        await update.message.reply_text(f"⚠️ Ocurrió un error al crear la cita: {e}")
    
    return ConversationHandler.END

async def cancelar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Cita cancelada.")
    return ConversationHandler.END


  
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    mensaje = update.message.text
    respuesta = generar_respuesta(mensaje)

    if respuesta == "__ACTIVAR_CITA__":
        await update.message.reply_text(
            "Entiendo que quieres hacer una cita. 🙋‍♀️\n"
            "Mi función es ayudarte con el manejo del estrés y la ansiedad relacionados con los estudios.\n"
            "Por favor, escribe /cita para comenzar el proceso. 😊"
        )
    else:
        await update.message.reply_text(respuesta)

# --- 5. Main ---
def main() -> None:
    logging.basicConfig(level=logging.INFO)
    application = Application.builder().token(BOT_TOKEN).build()

    # Comandos
    application.add_handler(CommandHandler("ayuda", ayuda))
    application.add_handler(CommandHandler("respiracion", respiracion))
    application.add_handler(CommandHandler("tipsestudio", tips_estudio))
    application.add_handler(CommandHandler("psicologia", psicologia))

    # Conversación de cita
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("cita", iniciar_cita)],
        states={
            PEDIR_FECHA: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_fecha)],
            PEDIR_HORA: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_hora)],
            PEDIR_TEMA: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_tema)],
            PEDIR_NOMBRE: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_nombre)],
            PEDIR_CORREO: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_correo)],
        },
        fallbacks=[CommandHandler("cancelar", cancelar)],
    )
    application.add_handler(conv_handler)

    # Mensajes normales (después de handlers específicos)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logging.info("Bot iniciado correctamente.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
